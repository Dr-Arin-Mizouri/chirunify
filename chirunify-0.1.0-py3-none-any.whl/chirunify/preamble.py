"""Inject the house dual-mode preamble around a normalised body.

The template (`templates/preamble.tex`) is the canonical block from the project's
reference file `latex scripts/Projectiles_2025/projectile_motion.tex`, with a few
`{{PLACEHOLDERS}}`. We never hand-write a preamble here -- we fill this one.
"""

from __future__ import annotations

from pathlib import Path
from typing import List

from . import macros

_TEMPLATE_PATH = Path(__file__).parent / "templates" / "preamble.tex"


def load_template() -> str:
    return _TEMPLATE_PATH.read_text(encoding="utf-8")


def extra_symbol_lines(symbols: List[str]) -> str:
    """\\providecommand lines for symbols the template doesn't already cover."""
    lines: List[str] = []
    for sym in symbols:
        if sym in macros.KNOWN_SYMBOLS:
            continue
        if sym in macros.EXTRA_SYMBOL_FALLBACKS:
            lines.append(macros.EXTRA_SYMBOL_FALLBACKS[sym])
        else:
            # Unknown: emit a harmless stub so the HTML build doesn't drop the arg
            # silently; TODO.md flags it for a human to give MathJax a real equivalent.
            lines.append(f"\\providecommand{{\\{sym}}}{{}}  % TODO: give MathJax an equivalent")
    return "\n".join(lines)


def render(body: str, title: str, symbols: List[str],
           reflection_title: str = "Points for consideration") -> str:
    """Return the full Chirun-ready .tex source. ``reflection_title`` is the "Points for
    consideration…" box heading, taken from the source so it stays faithful (it varies per
    experiment); it falls back to the short form only when the source has no ``\\considernote``."""
    template = load_template()
    header_right = title.upper()
    out = template.replace("{{EXPERIMENT_TITLE}}", title)
    out = out.replace("{{HEADER_RIGHT}}", header_right)
    out = out.replace("{{REFLECTION_TITLE}}", reflection_title)
    out = out.replace("{{EXTRA_SYMBOLS}}", extra_symbol_lines(symbols))
    out = out.replace("{{BODY}}", body)
    return out
