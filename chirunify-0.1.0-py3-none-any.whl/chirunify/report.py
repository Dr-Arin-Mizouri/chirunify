"""Render the human-facing TODO.md checklist from a list of Issues."""

from __future__ import annotations

from typing import List

from .models import Issue, Severity

_HEADINGS = {
    Severity.ERROR: "## Must fix before building (ERROR)",
    Severity.WARN: "## Should check (WARN)",
    Severity.TODO: "## Manual judgement needed (TODO)",
}
_INTRO = {
    Severity.ERROR: "These will break the Chirun build or produce inaccessible output.",
    Severity.WARN: "Likely problems -- confirm each is intentional.",
    Severity.TODO: "Decisions a human (or a later AI pass) must make.",
}


def render(issues: List[Issue], title: str) -> str:
    lines: List[str] = [f"# chirunify -- TODO for \"{title}\"", ""]
    if not issues:
        lines.append("No issues found. The package looks ready to build in Chirun.")
        lines.append("")
        return "\n".join(lines)

    lines.append(
        f"{len(issues)} item(s) to review. Upload the package to lti.chirun.org.uk "
        "(or a local Chirun install) once the ERRORs are cleared.")
    lines.append("")

    for severity in (Severity.ERROR, Severity.WARN, Severity.TODO):
        group = [i for i in issues if i.severity is severity]
        if not group:
            continue
        lines.append(_HEADINGS[severity])
        lines.append(_INTRO[severity])
        lines.append("")
        for issue in group:
            loc = f" ({issue.location})" if issue.location else ""
            lines.append(f"- [ ] **{issue.code}**{loc}: {issue.message}")
        lines.append("")
    return "\n".join(lines)
