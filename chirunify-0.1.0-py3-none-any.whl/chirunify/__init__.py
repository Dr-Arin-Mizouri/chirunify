"""chirunify -- prepare Durham lab scripts as Chirun-ready packages.

The conversion core (`pipeline.run_pipeline`) is deterministic and returns plain
strings/objects; only the CLI touches the filesystem. This keeps the core reusable
by a future web UI or Claude-API layer via the seams in `interfaces`.
"""

__version__ = "0.1.0"
