"""Extensibility seams for a future Claude-API layer.

The MVP is deterministic: the pipeline runs with the no-op enhancers below, which
simply defer every judgement call to a human via TODO.md. A later web/AI layer can
inject implementations that call the Claude API, without touching the pipeline.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Protocol, Tuple

from .models import Figure, Issue


class AltTextProvider(Protocol):
    def suggest(self, figure: Figure, context: str) -> Optional[str]:
        """Return alt text for a figure, or None to leave it for a human."""


class HeadingRestructurer(Protocol):
    def restructure(self, body: str) -> Tuple[str, List[Issue]]:
        """Return a possibly-restructured body plus any notes."""


class PackageResolver(Protocol):
    def resolve(self, package: str, body: str) -> Optional[str]:
        """Return advice on an unsupported package, or None."""


# --- Deterministic no-op implementations used by the MVP --------------------

class NoAltText:
    def suggest(self, figure: Figure, context: str) -> Optional[str]:
        return None


class IdentityRestructurer:
    def restructure(self, body: str) -> Tuple[str, List[Issue]]:
        return body, []


class FlagOnlyResolver:
    def resolve(self, package: str, body: str) -> Optional[str]:
        return None


@dataclass
class Enhancers:
    alt_text: AltTextProvider = field(default_factory=NoAltText)
    restructurer: HeadingRestructurer = field(default_factory=IdentityRestructurer)
    package_resolver: PackageResolver = field(default_factory=FlagOnlyResolver)


def default_enhancers() -> Enhancers:
    return Enhancers()
