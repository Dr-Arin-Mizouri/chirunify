"""Plain dataclasses shared across the pipeline. No I/O, no logic."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import List, Optional


class Severity(str, Enum):
    ERROR = "ERROR"  # blocks a correct Chirun build (or a --strict run)
    WARN = "WARN"    # likely a problem; human should look
    TODO = "TODO"    # a judgement call left for a human (e.g. write alt text)


@dataclass
class Issue:
    severity: Severity
    code: str
    message: str
    location: Optional[str] = None


@dataclass
class Figure:
    """An image referenced in the document body."""
    path: str                      # normalised, e.g. "media/fig1.jpg"
    caption: Optional[str] = None
    has_alttext: bool = False
    swapped_from: Optional[str] = None  # raster it was authored as, if routed to its SVG redraw


@dataclass
class PrepRequest:
    input_path: Path               # the source .tex file (resolved by the CLI)
    title: Optional[str] = None    # override; else inferred
    author: str = "Durham University Physics"
    slug: Optional[str] = None     # override; else derived from title/filename
    build_pdf: bool = False
    media_dir: str = ""            # image subfolder; "" = flat (images alongside the .tex)
    available_images: "frozenset[str]" = frozenset()  # image basenames beside the source .tex; enables raster->SVG-redraw swap


@dataclass
class Document:
    """The normalised body plus everything discovered while normalising it."""
    body: str
    figures: List[Figure] = field(default_factory=list)
    symbols: List[str] = field(default_factory=list)  # non-standard maths macros seen
    title: Optional[str] = None
    issues: List[Issue] = field(default_factory=list)
    reflection_title: Optional[str] = None  # the source's own "Points for consideration…" phrase


@dataclass
class PrepResult:
    slug: str
    title: str
    tex: str
    config: dict
    issues: List[Issue] = field(default_factory=list)
    figures: List[Figure] = field(default_factory=list)
    # Extra static files to ship in the package, keyed by their path inside the
    # package (e.g. "static/custom.css") -> file contents. The CLI writes these
    # into the output folder and the zip. Kept as strings so the core stays I/O-free.
    static_files: "dict[str, str]" = field(default_factory=dict)

    @property
    def tex_filename(self) -> str:
        return f"{self.slug}.tex"

    def errors(self) -> List[Issue]:
        return [i for i in self.issues if i.severity is Severity.ERROR]


def slugify(text: str) -> str:
    """'Projectile Motion' -> 'projectile_motion' (lab-script filename convention)."""
    text = text.strip().lower()
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return text.strip("_") or "labscript"
