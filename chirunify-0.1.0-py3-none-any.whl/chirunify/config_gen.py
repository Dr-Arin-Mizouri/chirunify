"""Build the Chirun `config.yml` structure (as a dict).

The shape matches the project's existing examples exactly:
    latex scripts/Projectiles_2025/config.yml, latex scripts/Circuits1_2025/config.yml
`source` is derived from the real output .tex filename, so it can never drift from the
file (this is the class of bug the Circuits1 example has: source: main.tex).
"""

from __future__ import annotations


def build(title: str, slug: str, author: str, build_pdf: bool = False) -> dict:
    return {
        "author": author,
        "title": title,
        "build_pdf": build_pdf,
        "structure": [
            {
                "type": "standalone",
                "source": f"{slug}.tex",
                "title": title,
                "topbar": False,
            }
        ],
    }
