"""Build the Chirun `config.yml` structure (as a dict).

The shape matches the project's existing examples exactly:
    latex scripts/Projectiles_2025/config.yml, latex scripts/Circuits1_2025/config.yml
`source` is derived from the real output .tex filename, so it can never drift from the
file (this is the class of bug the Circuits1 example has: source: main.tex).
"""

from __future__ import annotations

from .assets import CUSTOM_CSS_FILENAME


def build(title: str, slug: str, author: str, build_pdf: bool = False) -> dict:
    return {
        "author": author,
        "title": title,
        "build_pdf": build_pdf,
        # Load our extra stylesheet (packaged at static/custom.css) after Chirun's
        # theme, to switch off the theme's heading underline. See assets.py. Chirun's
        # convention is the bare filename here; the file lives in static/.
        "css": [CUSTOM_CSS_FILENAME],
        "structure": [
            {
                "type": "standalone",
                "source": f"{slug}.tex",
                "title": title,
                "topbar": False,
            }
        ],
    }
