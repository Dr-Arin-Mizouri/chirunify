"""Static assets shipped inside every Chirun package.

This is a single custom stylesheet that loads *after* Chirun's theme and (1) switches
off the heading underline and (2) styles chirunify's accessible data tables so they keep
the narrow, centred, header-underline look of the original ``.tabular`` without using that
class (which would strip the header semantics -- see below). Chirun's default theme
underlines every heading (the item title, subtitle and every ``h1``--``h6``) with this rule
in its own ``styles.css``::

    article.item-content :is(h1, h2, h3, h4, h5, h6) {
        text-decoration: underline;
        text-decoration-thickness: 0.2em;
        text-underline-offset: 0.3em;
    }

We can't edit the server-side theme, but Chirun supports package-level extra CSS: a
file in the package's ``static/`` folder, named in ``config.yml``'s ``css:`` list, is
copied into the build and linked *after* ``styles.css`` (confirmed against the theme's
own ``base.html`` template). Because our override uses the same selector and loads
later, it wins -- no theme fork, no developer change needed. Link underlines are a
*separate* theme rule and are deliberately left untouched (they are a genuine
accessibility feature -- don't rely on colour alone).
"""

from __future__ import annotations

# Bare filename, matching Chirun's convention: config.yml lists `css: [custom.css]`
# (not `static/custom.css`), and the file itself lives at `static/custom.css`. The
# `static_url` filter resolves the bare name to the output `static/` folder.
CUSTOM_CSS_FILENAME = "custom.css"

# Chirun copies static files into a `static/` subfolder of the package.
CUSTOM_CSS_ARCNAME = f"static/{CUSTOM_CSS_FILENAME}"

CUSTOM_CSS = """\
/* Loaded by chirunify, after Chirun's theme (see config.yml `css:`).
 *
 * Chirun's default theme underlines every heading -- the title, subtitle and all
 * h1-h6 -- via, in its own styles.css:
 *
 *     article.item-content :is(h1, h2, h3, h4, h5, h6) {
 *         text-decoration: underline;
 *         text-decoration-thickness: 0.2em;
 *         text-underline-offset: 0.3em;
 *     }
 *
 * For these accessible lab scripts we switch that off. This file loads after the
 * theme's styles.css and uses the same selector, so this rule wins. Link underlines
 * are a separate theme rule and are left untouched.
 */
article.item-content :is(h1, h2, h3, h4, h5, h6) {
    text-decoration: none;
}

/* Accessible data tables (chirunify emits these as a raw-HTML <table>).
 *
 * We must NOT put class="tabular" on them: the theme sets `.tabular{display:inline-block}`,
 * and changing a <table>'s display to a non-table value strips its header semantics from the
 * accessibility tree, so VoiceOver stops announcing the <th scope="col"> columns. Instead the
 * table stays a native display:table and we restore the *look* .tabular used to give -- narrow,
 * centred, a single rule under the header -- with the class below. A class selector outranks
 * the theme's `table{width:100%}` / `td{...}` element rules, so no !important is needed. */
table.chirun-datatable {
    display: table;                 /* keep native table semantics (a11y) */
    width: -webkit-fit-content;
    width: fit-content;             /* shrink to content instead of the theme's 100% */
    max-width: 100%;
    margin: 1em auto;               /* centre it */
    line-height: 1.5;
    border-collapse: collapse;
}
table.chirun-datatable th,
table.chirun-datatable td {
    border: 0;                      /* no per-row rules */
    padding: 0.25em 0.9em;
}
table.chirun-datatable thead th {
    border-bottom: 1px solid currentColor;   /* the single header underline */
}
"""
