"""Turn a raw LaTeX document into a Chirun-normalised body, recording figures,
symbols and any manual-review flags along the way.

Input is LaTeX that already compiles (e.g. cleanly on Overleaf). We keep only the
document body -- the author's own preamble is dropped and replaced by the house
dual-mode preamble in ``preamble.py`` -- map standard sectioning to the house
macros, and route every image through ``media/``.

The guiding rule (from SKILL.md): never silently transform something we are unsure
about -- leave it as-is and raise a TODO instead. Each step is a small pure function
so it can be unit-tested in isolation.
"""

from __future__ import annotations

import re
from typing import List, Optional, Tuple

from . import crossref, macros
from .models import Document, Figure, Issue, Severity

_DOC_RE = re.compile(r"\\begin\{document\}(.*)\\end\{document\}", re.DOTALL)
_DOCTITLE_RE = re.compile(r"\\doctitle\{([^}]*)\}")
_HEADING_TITLE_RE = re.compile(r"\\(?:heading|section)\*?\{([^}]*)\}")

# --- URLs -> descriptive hyperlinks ------------------------------------------
# A link must show human-readable text, never the raw address: a screen reader
# otherwise reads the whole URL out character by character, and a bare URL is
# meaningless out of context in a screen reader's link list (WCAG 2.4.4). So we
# rewrite \url{u}, \href{u}{<the url again>} and bare http(s) URLs to
# \href{u}{label}, deriving a first-pass label from the URL's last path segment
# and raising a TODO so a human refines it ("computing and software" ->
# "computing and software skills page"). A \href that already has descriptive
# text is left untouched.
_URL_CMD_RE = re.compile(
    r"\\href\{(?P<hurl>[^{}]*)\}\{(?P<htext>[^{}]*(?:\{[^{}]*\}[^{}]*)*)\}"  # \href{u}{text}
    r"|\\url\{(?P<uurl>[^{}]*)\}"                                            # \url{u}
    r"|(?P<bare>https?://[^\s{}\\)\]]+)"                                     # bare http(s) URL
)
_NOLINKURL_RE = re.compile(r"^\\nolinkurl\{([^{}]*)\}$")
_URLISH_RE = re.compile(r"^(?:https?://|www\.)", re.IGNORECASE)
_TRAILING_PUNCT = ".,;:!?"
# A \newcommand/\def that stores a URL (e.g. \newcommand{\skillsurl}{https://...}).
# These live in the author preamble, which we drop -- so any \skillsurl used in the body
# would become an undefined macro. We inline them into the body first.
_URL_MACRO_DEF_RE = re.compile(
    r"\\(?:new|renew)command\*?\s*\{?\\([a-zA-Z]+)\}?\s*\{([^{}]*)\}"
    r"|\\def\s*\\([a-zA-Z]+)\s*\{([^{}]*)\}")
# Matches both \includegraphics and \includesvg; captures (opts, path).
_INCLUDEGRAPHICS_RE = re.compile(r"\\include(?:graphics|svg)(\[[^\]]*\])?\{([^}]+)\}")
_SYMBOL_RE = re.compile(r"\\(sym[a-zA-Z]+|smblksquare|smwhtsquare)\b")

# --- Bold maths inside a non-bold callout box --------------------------------
# The house callout boxes (safety/whiteboard/task/prep/reflection) render with a
# NON-bold body in Chirun's HTML -- only the box *title* is bold. When an author
# wrote the box bold in their own PDF preamble they often wrapped its maths in
# \symbf/\symbfup (bold maths) so the symbols matched that bold text. Once the box
# body is not bold, those symbols read as stray bold -- e.g. a green "Preparatory
# Task" box whose plain text is thin but whose \gamma, \delta ... come out bold.
# So *inside these boxes only* we drop the bold: \symbf{x} -> {x} (maths italic,
# the default) and \symbfup{x} -> \symup{x} (upright, non-bold). Bold maths OUTSIDE
# a box -- a vector like \symbf{a}, a bold table header -- is deliberate; it is left
# untouched, so this never un-bolds something that is meant to be bold.
_BOX_ENVS = tuple(sorted(macros.HOUSE_ENVIRONMENTS))  # quoteblock, preptask, considerlist, framed
_SYMBFUP_RE = re.compile(r"\\symbfup(?![a-zA-Z])")
_SYMBF_RE = re.compile(r"\\symbf(?![a-zA-Z])")


def extract_body(text: str) -> Tuple[str, bool]:
    """Return (body, had_document_env). If there is a full document, keep only what is
    between \\begin{document} and \\end{document}; otherwise treat the whole thing as a
    fragment."""
    m = _DOC_RE.search(text)
    if m:
        return m.group(1).strip("\n"), True
    return text.strip("\n"), False


def infer_title(text: str) -> Optional[str]:
    """Best-effort title: an explicit \\doctitle, else the first heading/section."""
    m = _DOCTITLE_RE.search(text)
    if m:
        return m.group(1).strip()
    m = _HEADING_TITLE_RE.search(text)
    if m:
        # Strip a leading manual number like "1.\quad " if present.
        title = m.group(1).strip()
        title = re.sub(r"^\d+\.?\s*(\\quad)?\s*", "", title).strip()
        return title or None
    return None


def strip_doctitle(body: str) -> str:
    """Remove any \\doctitle{...} line; the template injects its own."""
    return _DOCTITLE_RE.sub("", body, count=1).lstrip("\n")


def map_headings(body: str) -> str:
    """Map raw \\section/\\subsection/\\subsubsection to house macros. A body that
    already uses the house macros is unaffected (there is nothing to match)."""
    for pattern, repl in macros.HEADING_MAP:
        body = pattern.sub(repl, body)
    return body


def find_url_macros(source: str) -> dict:
    """URL-valued macros defined in the source preamble, e.g.
    ``\\newcommand{\\skillsurl}{https://...}`` -> ``{'skillsurl': 'https://...'}``. Only
    values that look like a URL are taken, so ordinary text macros are left alone."""
    found: dict = {}
    for m in _URL_MACRO_DEF_RE.finditer(source):
        name = m.group(1) or m.group(3)
        value = (m.group(2) if m.group(1) else m.group(4)).strip()
        if "://" in value or value.lower().startswith("www."):
            found[name] = value
    return found


def inline_url_macros(body: str, url_macros: dict) -> str:
    """Replace each ``\\name`` used in the body with its literal URL, so the reference
    survives the author preamble being dropped. ``re.sub`` with a function keeps the URL
    literal (no backslash/group interpretation in the replacement)."""
    for name, value in url_macros.items():
        body = re.sub(r"\\" + re.escape(name) + r"(?![a-zA-Z])",
                      lambda _m, v=value: v, body)
    return body


_CONSIDERNOTE_DEF_RE = re.compile(
    r"\\newcommand\*?\s*\{\\considernote\}\s*\{((?:[^{}]|\{[^{}]*\})*)\}")
# Spacing/sizing commands whose braced argument is a dimension, not text -- drop the command
# and *only its own* argument(s), matched by exact arity so an adjacent text group like
# {\itshape ...} that follows \vspace{2pt} is NOT swallowed.
_SPACING_CMD_RE = re.compile(
    r"\\(?:vspace|hspace|vskip|hskip)\*?\{[^{}]*\}"        # one dimension argument
    r"|\\(?:fontsize|setlength)\*?\{[^{}]*\}\{[^{}]*\}")   # two arguments


def considernote_title(source: str) -> Optional[str]:
    """The reflection box's title, taken faithfully from the source's own ``\\considernote``
    lead-in (e.g. ``{\\itshape Points for consideration and comment in your laboratory
    notebook:}`` -> "Points for consideration and comment in your laboratory notebook"). This
    phrase varies per experiment, so it must come from the source, not a fixed string. Returns
    None if there is no (non-empty) ``\\considernote`` definition."""
    m = _CONSIDERNOTE_DEF_RE.search(source)
    if not m:
        return None
    text = _SPACING_CMD_RE.sub(" ", m.group(1))    # drop \vspace{2pt} etc. (dimension args)
    text = re.sub(r"\\[a-zA-Z]+\*?", " ", text)     # drop \par \itshape \emph \nobreak ... (keep wrapped text)
    text = text.replace("{", " ").replace("}", " ")  # drop the grouping braces
    text = re.sub(r"\s+", " ", text).strip().rstrip(":").strip()
    return text or None


def _tex_escape(text: str) -> str:
    """Escape the LaTeX specials that can appear in a URL-derived label."""
    return re.sub(r"([&%#$])", r"\\\1", text)


def _url_label(url: str) -> str:
    """A first-pass, human-readable label for a URL: its last path segment with
    separators turned into spaces, else the host without a leading 'www.'."""
    core = url.split("#", 1)[0].split("?", 1)[0].rstrip("/")
    core = re.sub(r"^[a-zA-Z][a-zA-Z0-9+.\-]*://", "", core)   # strip scheme
    parts = [p for p in core.split("/") if p]
    if len(parts) > 1:
        seg = re.sub(r"\.(s?html?|php|aspx?|jsp|pdf)$", "", parts[-1], flags=re.I)
        label = re.sub(r"[-_+]+", " ", seg).strip()
        if label:
            return label
    host = parts[0] if parts else core
    return re.sub(r"^www\.", "", host, flags=re.I)


_ALTTEXT_RE = re.compile(r"\\alttext\{(?:[^{}]|\{[^{}]*\})*\}")


def normalize_urls(body: str) -> Tuple[str, List[Issue]]:
    """Rewrite raw-URL links to descriptive ``\\href{url}{label}``; return the new
    body and one TODO per rewrite so a human confirms the auto-derived label. A
    \\href that already carries descriptive (non-URL) text is left as-is. A URL inside
    an ``\\alttext{...}`` is left untouched -- alt text is a plain-text image description,
    so a URL there is being quoted (e.g. text shown in a screenshot), not linked; wrapping
    it in ``\\href`` would corrupt the description."""
    issues: List[Issue] = []
    protected = [(m.start(), m.end()) for m in _ALTTEXT_RE.finditer(body)]

    def repl(m: re.Match) -> str:
        if any(start <= m.start() < end for start, end in protected):
            return m.group(0)  # inside \alttext{...}: never linkify
        trailer = ""
        if m.group("bare") is not None:
            url = m.group("bare")
            while url and url[-1] in _TRAILING_PUNCT:  # don't swallow sentence punctuation
                trailer = url[-1] + trailer
                url = url[:-1]
        elif m.group("uurl") is not None:
            url = m.group("uurl")
        else:  # \href{url}{text}
            url = m.group("hurl")
            text = m.group("htext").strip()
            inner = _NOLINKURL_RE.match(text)
            visible = inner.group(1).strip() if inner else text
            already_descriptive = (
                visible
                and not _URLISH_RE.match(visible)
                and visible.rstrip("/") != url.rstrip("/"))
            if already_descriptive:
                return m.group(0)
        label = _tex_escape(_url_label(url))
        issues.append(Issue(Severity.TODO, "URL-LINK-TEXT",
            f"Showed the URL {url} as the link text '{label}' (auto-derived from the "
            "address). Check it names the page for a reader -- e.g. add 'skills page' -- so "
            "a screen reader announces the destination, not the whole URL."))
        return f"\\href{{{url}}}{{{label}}}" + trailer

    return _URL_CMD_RE.sub(repl, body), issues


def _enclosing_block(body: str, start: int, end: int) -> str:
    """Text of the figure/minipage block enclosing [start:end], else a small window.
    Used to decide whether an image already carries an \\alttext."""
    fig_open = body.rfind(r"\begin{figure}", 0, start)
    fig_close = body.find(r"\end{figure}", end)
    if fig_open != -1 and fig_close != -1:
        return body[fig_open:fig_close]
    mp_open = body.rfind(r"\begin{minipage}", 0, start)
    mp_close = body.find(r"\end{minipage}", end)
    if mp_open != -1 and mp_close != -1:
        return body[mp_open:mp_close]
    return body[max(0, start - 400):min(len(body), end + 400)]


def _caption_near(block: str) -> Optional[str]:
    m = re.search(r"\\figcaption\{([^}]*)\}", block) or re.search(r"\\caption\{([^}]*)\}", block)
    return m.group(1).strip() if m else None


_RASTER_SUFFIXES = (".png", ".jpg", ".jpeg", ".gif")


def _svg_redraw_of(basename: str, available_images: "frozenset[str]") -> Optional[str]:
    """If ``basename`` is a raster whose accessible SVG redraw ``<stem>_SVG.svg`` sits
    alongside it (i.e. is in ``available_images``), return that SVG's filename; else None.

    This routes a figure authored with a raster -- so the Overleaf PDF compiles with plain
    \\includegraphics, no Inkscape/shell-escape -- to its crisp, accessible SVG for Chirun's
    HTML. The raster still travels in the zip (harmless), but the Chirun .tex points at the SVG.
    A figure authored directly as an SVG has no raster basename here, so it is never touched."""
    if not basename.lower().endswith(_RASTER_SUFFIXES):
        return None
    candidate = f"{basename.rsplit('.', 1)[0]}_SVG.svg"
    return candidate if candidate in available_images else None


def normalize_figures(body: str, media_dir: str,
                      available_images: "frozenset[str]" = frozenset()) -> Tuple[str, List[Figure]]:
    """Rewrite \\includegraphics/\\includesvg paths to <media_dir>/<basename> and record each
    figure (its caption, and whether its enclosing block already has \\alttext). An empty
    ``media_dir`` puts images alongside the .tex (bare basename, no subfolder).

    A figure authored with a raster (``fig.jpg``) whose SVG redraw (``fig_SVG.svg``) is present
    in ``available_images`` is swapped to reference that SVG: the Overleaf source keeps the
    raster (reliable PDF), while Chirun's HTML gets the accessible vector. A raster with no
    redraw alongside it, or an image already referenced as an SVG, is left as referenced."""
    figures: List[Figure] = []

    def repl(match: re.Match) -> str:
        opts = match.group(1) or ""
        raw = match.group(2)
        basename = raw.replace("\\", "/").split("/")[-1]
        swapped_from = None
        redraw = _svg_redraw_of(basename, available_images)
        if redraw:
            swapped_from, basename = basename, redraw
        new_path = f"{media_dir}/{basename}" if media_dir else basename
        block = _enclosing_block(body, match.start(), match.end())
        figures.append(Figure(
            path=new_path,
            caption=_caption_near(block),
            has_alttext="\\alttext" in block,
            swapped_from=swapped_from,
        ))
        # Always emit \includegraphics (graphicx is loaded; \includesvg is not) so the
        # reference is well-formed for Chirun.
        return f"\\includegraphics{opts}{{{new_path}}}"

    new_body = _INCLUDEGRAPHICS_RE.sub(repl, body)
    return new_body, figures


def _drop_bold_maths(span: str) -> str:
    """Un-bold the maths in ``span`` (the body of a non-bold box): ``\\symbfup`` ->
    ``\\symup`` (upright, non-bold) and ``\\symbf`` removed so its ``{...}`` group is
    plain maths (italic, the default). Braces and everything else are left in place, so
    ``\\symbf{\\gamma}`` -> ``{\\gamma}`` and ``\\symbfup{k\\Omega}`` -> ``\\symup{k\\Omega}``."""
    span = _SYMBFUP_RE.sub(r"\\symup", span)
    span = _SYMBF_RE.sub("", span)
    return span


def _map_command_arg(body: str, cmd: str, transform) -> str:
    """Apply ``transform`` to the balanced-brace argument of every ``\\cmd{...}`` in
    ``body``; the command name and its braces are kept. Brace matching respects nesting
    and ``\\{``/``\\}`` escapes, so an argument like ``... $\\symbf{\\varepsilon}$ ...`` is
    captured whole. A ``\\cmd`` with no following brace, or an unbalanced one, is left as-is."""
    token = "\\" + cmd
    out: List[str] = []
    i, n = 0, len(body)
    while True:
        j = body.find(token, i)
        if j == -1:
            out.append(body[i:])
            break
        k = j + len(token)
        if k < n and body[k].isalpha():        # \whiteboardish is a different command
            out.append(body[i:k])
            i = k
            continue
        b = k
        while b < n and body[b] in " \t\r\n":   # allow whitespace before the {
            b += 1
        if b >= n or body[b] != "{":            # no braced argument -> leave untouched
            out.append(body[i:k])
            i = k
            continue
        depth, e = 0, b
        while e < n:
            c = body[e]
            if c == "\\":
                e += 2                            # skip an escaped char (e.g. \{ \} \\)
                continue
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    break
            e += 1
        if e >= n:                                # unbalanced: bail out, change nothing
            out.append(body[i:])
            break
        out.append(body[i:b + 1])                 # up to and including the opening {
        out.append(transform(body[b + 1:e]))      # the transformed inner argument
        out.append("}")
        i = e + 1
    return "".join(out)


def unbold_box_maths(body: str) -> str:
    """Drop stray bold maths (``\\symbf``/``\\symbfup``) inside the house callout boxes,
    which Chirun renders with a non-bold body. Covers the box *environments* (preptask,
    quoteblock, considerlist, framed) and the ``\\whiteboard{...}`` command. Bold maths
    anywhere else -- vectors, table headers -- is intentional and untouched."""
    for env in _BOX_ENVS:
        pat = re.compile(r"\\begin\{" + re.escape(env) + r"\}.*?\\end\{" + re.escape(env) + r"\}",
                         re.DOTALL)
        body = pat.sub(lambda m: _drop_bold_maths(m.group(0)), body)
    return _map_command_arg(body, "whiteboard", _drop_bold_maths)


def collect_symbols(body: str) -> List[str]:
    """Non-standard maths macros used in the body (for \\providecommand fallbacks)."""
    return sorted({m.group(1) for m in _SYMBOL_RE.finditer(body)})


def normalize(latex: str, media_dir: str,
              available_images: "frozenset[str]" = frozenset()) -> Document:
    """Full normalisation of a LaTeX source (a full document or a fragment) into a
    Chirun-ready body. ``available_images`` is the set of image basenames sitting beside the
    source .tex; it lets a raster figure be routed to its ``_SVG.svg`` redraw for the HTML."""
    title = infer_title(latex)
    url_macros = find_url_macros(latex)  # capture \skillsurl-style defs before the preamble is dropped
    reflection_title = considernote_title(latex)  # faithful reflection-box title from the source
    body, _ = extract_body(latex)
    body = strip_doctitle(body)
    body = map_headings(body)
    body = unbold_box_maths(body)  # drop stray bold maths inside non-bold callout boxes
    body = inline_url_macros(body, url_macros)  # \skillsurl -> its literal URL in the body
    body, url_issues = normalize_urls(body)  # raw-URL links -> descriptive \href
    body, figures = normalize_figures(body, media_dir, available_images)
    body = crossref.apply(body)  # number equations; link equation mentions + citations
    symbols = collect_symbols(body)

    issues: List[Issue] = list(url_issues)
    return Document(body=body.strip("\n"), figures=figures, symbols=symbols,
                    title=title, issues=issues, reflection_title=reflection_title)
