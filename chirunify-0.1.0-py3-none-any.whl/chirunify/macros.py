"""House conventions as pure data, sourced from the project's SKILL.md table and
the copilot guide's style-mapping table. No logic lives here."""

from __future__ import annotations

import re
from typing import Dict, List, Tuple

# --- Sectioning: raw LaTeX -> house semantic macros -------------------------
# (compiled pattern, replacement). Applied to a LaTeX *body*. Starred and
# unstarred forms both map to the starred house command (manual numbering).
HEADING_MAP: List[Tuple[re.Pattern, str]] = [
    (re.compile(r"\\section\*?\{"), r"\\heading{"),
    (re.compile(r"\\subsection\*?\{"), r"\\subheading{"),
    (re.compile(r"\\subsubsection\*?\{"), r"\\taskheading{"),
]

# House macros the template defines (used to avoid re-mapping already-house source).
HOUSE_MACROS = {
    "doctitle", "heading", "subheading", "taskheading", "figcaption",
    "considernote", "demonote", "penicon", "whiteboard", "eqnum", "alttext",
}
HOUSE_ENVIRONMENTS = {"quoteblock", "preptask", "considerlist", "framed"}

# --- Chirun / plasTeX package support (from the copilot guide cheatsheet) ----
# Packages Chirun re-implements or tolerates in the HTML build.
SUPPORTED_PACKAGES = {
    "chirun", "amsmath", "graphicx", "enumitem", "xcolor", "tcolorbox",
    "framed", "fancyhdr", "geometry", "hyperref", "url", "xurl", "fontspec",
    "unicode-math", "changepage", "caption", "subcaption", "cleveref",
    "natbib", "biblatex", "amssymb", "amsfonts",
}
# Packages known to break the HTML build or restyle globally -> keep out of HTML.
BANNED_PACKAGES = {
    "sectsty", "abstract", "cite", "cantarell", "titlesec", "titling",
}

# --- Non-standard maths symbols the preamble already provides fallbacks for --
KNOWN_SYMBOLS = {"symup", "symbf", "symbfup", "smblksquare"}

# Best-effort MathJax fallbacks for a few extra symbols we might meet. Anything
# not here is still emitted as a \providecommand{...}{} stub + flagged as a TODO.
EXTRA_SYMBOL_FALLBACKS: Dict[str, str] = {
    "symsf": r"\providecommand{\symsf}[1]{\mathsf{#1}}",
    "symit": r"\providecommand{\symit}[1]{\mathit{#1}}",
    "symbb": r"\providecommand{\symbb}[1]{\mathbb{#1}}",
    "smwhtsquare": r"\providecommand{\smwhtsquare}{\square}",
}
