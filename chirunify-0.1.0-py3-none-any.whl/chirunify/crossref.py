"""Deterministic cross-referencing pass: number displayed equations, and turn plain-text
equation, figure/table and citation mentions into clickable links.

House conventions handled (from the reference lab-script sources):
  * displayed equations:  ``\\begin{equation*} ... \\eqnum{k} \\end{equation*}``  (or ``\\[ ... \\]``)
  * equation mentions:     ``Equation~(k)`` / ``equation (k)`` / ``Eq.~(k)`` / ``Equations (1) and (2)``
  * figures/tables:        a ``\\figcaption{Figure k: ...}`` (author-numbered in the caption text)
  * figure/table mentions: ``Figure~k`` / ``Fig. k`` / ``Table k`` / ``Figures 1 and 2``
  * citations:             ``[k]`` with a "References" section that lists ``[k] ...``

An equation that the author numbered keeps its number (as an explicit ``\\tag`` so it shows
in both the PDF and Chirun's MathJax HTML) and gains a ``\\label`` so mentions can point at
it; mentions become ``\\eqref``. Figures/tables aren't ``\\caption`` auto-numbered (the scripts
use a plain ``\\figcaption``), so -- like citations -- each caption's "Figure k" label gets a
named ``\\hypertarget`` and every "Figure k" mention becomes a ``\\hyperlink`` to it. Listed
citations likewise become ``\\hyperlink`` links to a ``\\hypertarget`` on the matching reference
entry. Author numbers are preserved throughout -- a mention of "Figure 2" still shows "2".

Everything the pass must not touch -- LaTeX comments, maths, ``\\alttext``/``\\caption``
content, and URLs -- is masked out first, so a ``[k]`` inside alt text or a commented-out
equation is left alone (the guiding rule from SKILL.md: never transform what we are unsure
of).
"""

from __future__ import annotations

import re
from typing import List, Set, Tuple

# A displayed equation: \[ ... \]  or  \begin{equation}/{equation*} ... \end{...}
_DISPLAY_RE = re.compile(
    r"\\\[(?P<sq>.*?)\\\]"
    r"|\\begin\{equation\*?\}(?P<env>.*?)\\end\{equation\*?\}",
    re.DOTALL,
)
# An equation number/label: plain digits ("3") OR an appendix-style label ("A.1", "B.2").
# Must start alphanumeric, then any of letters/digits/dots/hyphens. Matching more than \d+ is
# what lets an appendix equation (\eqnum{A.1}) be turned into a NUMBERED equation environment
# for Chirun -- a \tag inside an unnumbered equation* does not render its number in Chirun, so
# without this the "(A.1)" number vanishes online and its \eqref mentions have no target.
_EQ_LABEL = r"[A-Za-z0-9][A-Za-z0-9.\-]*"
# A manual equation number the author already gave: \eqnum{k} or \tag{k}.
_EQNUM_RE = re.compile(r"\\(?:eqnum|tag)\s*\{\s*(" + _EQ_LABEL + r")\s*\}")
# First mention of an equation: "Equation (3)", "equation~(3)", "Eq. (A.1)".
_EQREF_WORD_RE = re.compile(
    r"(?P<word>[Ee]quations?|[Ee]q\.?)[\s~]*\(\s*(?P<num>" + _EQ_LABEL + r")\s*\)")
# A follow-on number in a run like "Equations (1), (2) and (4)" / "(A.1) and (A.2)".
_EQREF_CHAIN_RE = re.compile(
    r"(?P<prev>\\eqref\{eq:" + _EQ_LABEL + r"\})(?P<sep>[\s~]*(?:and|to|&|,)?[\s~]*)"
    r"\(\s*(?P<num>" + _EQ_LABEL + r")\s*\)")
# A citation like [3] -- but not \[ (display math): negative lookbehind on a backslash.
_CITE_RE = re.compile(r"(?<!\\)\[\s*(\d+)\s*\]")

# Figures/tables are author-numbered *inside their caption text* ("Figure 2: ...") -- the
# scripts use a plain \figcaption, not \caption auto-numbering -- so we mirror the citation
# approach: anchor the caption's "Figure 2" label with a \hypertarget and turn "Figure 2"
# mentions into \hyperlink jumps to it. Author numbers are preserved.
_FLOAT_KINDS = (("Figure", "fig"), ("Table", "tab"))
# A caption macro and its (brace-balanced to one level) body.
_CAPTION_RE = re.compile(
    r"(?P<open>\\(?:figcaption|tablecaption|caption)\*?\{)"
    r"(?P<body>(?:[^{}]|\{[^{}]*\})*)(?P<close>\})")
# The "Figure 2" / "Table 3" label to anchor at the front of a caption.
_CAP_LABEL_RE = re.compile(r"(?P<word>Figure|Table)(?P<sp>[\s~]+)(?P<num>\d+)")
# First mention of a float in prose: "Figure 2", "fig.~2", "Table 3", "Figures 1"
# (case-insensitive first letter, like the equation linker's [Ee]quation).
_FIGREF_WORD_RE = re.compile(
    r"\b(?P<word>[Ff]igures?|[Ff]igs?\.?|[Tt]ables?)(?P<sp>[\s~]+)(?P<num>\d+)")
# A follow-on number in a run like "Figures 1, 2 and 4".
_FIGREF_CHAIN_RE = re.compile(
    r"(?P<prev>\\hyperlink\{(?P<pfx>fig|tab):\d+\}\{\d+\})"
    r"(?P<sep>[\s~]*(?:and|to|&|,)?[\s~]*)(?P<num>\d+)")
# A "References" heading (house macro or a raw sectioning command).
_REF_HEADING_RE = re.compile(
    r"\\(?:sub)?(?:heading|section|subsection)\*?\{[^}]*[Rr]eferences[^}]*\}")

# Regions the link/number passes must never edit. Masked out, transformed around, restored.
_COMMENT_RE = re.compile(r"(?<!\\)%[^\n]*")
_PROTECT_RE = re.compile(
    r"\$\$.*?\$\$"                                                    # $$ ... $$
    r"|\$.*?\$"                                                       # $ ... $
    r"|\\\(.*?\\\)"                                                   # \( ... \)
    r"|\\begin\{(?P<env>equation\*?|align\*?|gather\*?|multline\*?|eqnarray\*?)\}.*?\\end\{(?P=env)\}"
    r"|\\alttext\{[^{}]*\}"                                           # \alttext{...}
    r"|\\(?:figcaption|tablecaption|caption)\*?\{(?:[^{}]|\{[^{}]*\})*\}"  # captions (may hold a \hypertarget)
    r"|\\hyper(?:link|target)\{[^{}]*\}\{(?:[^{}]|\{[^{}]*\})*\}"     # already-linked cross-refs (idempotency)
    r"|\\url\{[^{}]*\}|\\href\{[^{}]*\}\{[^{}]*\}",                   # URLs
    re.DOTALL,
)
_SENTINEL_RE = re.compile("\x00(\\d+)\x00")


def _mask(body: str, pattern: re.Pattern, store: List[str]) -> str:
    """Replace every match of `pattern` with an inert sentinel, appending the originals to
    `store`. Sentinels contain no LaTeX the later passes react to."""
    def repl(m: re.Match) -> str:
        store.append(m.group(0))
        return f"\x00{len(store) - 1}\x00"
    return pattern.sub(repl, body)


def _unmask(body: str, store: List[str]) -> str:
    # Loop so a sentinel restored from a protected region (which may itself contain an
    # earlier comment sentinel) is expanded too. Terminates: masks form a DAG (protected
    # regions may reference earlier comment sentinels, never the reverse).
    while store and _SENTINEL_RE.search(body):
        body = _SENTINEL_RE.sub(lambda m: store[int(m.group(1))], body)
    return body


def _number_equations(body: str) -> Tuple[str, Set[str]]:
    """Give each author-numbered displayed equation an explicit ``\\tag`` (its own number)
    plus a ``\\label{eq:k}``. Equations the author left unnumbered are passed through
    unchanged. Returns the new body and the set of numbers now labelled."""
    keyed: Set[str] = set()

    def repl(m: re.Match) -> str:
        inner = m.group("sq") if m.group("sq") is not None else m.group("env")
        mk = _EQNUM_RE.search(inner)
        if not mk:
            return m.group(0)  # unnumbered display equation -> leave exactly as it was
        k = mk.group(1)
        inner = _EQNUM_RE.sub("", inner).strip()
        keyed.add(k)
        # A NUMBERED equation environment (not equation*) so the \label resolves in Chirun
        # -- Chirun's own tests use `\begin{equation}\label{..} ... \tag{k}`. The \tag keeps
        # the author's printed number; the numbered env gives the label a resolvable target.
        return (f"\\begin{{equation}}\n  {inner}\n  \\tag{{{k}}}\\label{{eq:{k}}}\n"
                f"\\end{{equation}}")

    return _DISPLAY_RE.sub(repl, body), keyed


def _link_equation_refs(body: str, keyed: Set[str]) -> str:
    """Turn "Equation (k)" (and each number in "Equations (1) and (2)") into \\eqref links,
    but only where equation k exists."""
    def first(m: re.Match) -> str:
        num = m.group("num")
        if num not in keyed:
            return m.group(0)
        return f"{m.group('word')}~\\eqref{{eq:{num}}}"
    body = _EQREF_WORD_RE.sub(first, body)

    def chain(m: re.Match) -> str:
        num = m.group("num")
        if num not in keyed:
            return m.group(0)
        return f"{m.group('prev')}{m.group('sep')}\\eqref{{eq:{num}}}"
    prev = None
    while prev != body:            # repeat so "(1), (2) and (4)" fully resolves
        prev = body
        body = _EQREF_CHAIN_RE.sub(chain, body)
    return body


def _link_citations(body: str) -> str:
    """Turn in-text "[k]" into clickable links, and give each reference-list "[k]" a matching
    anchor. Uses \\hypertarget/\\hyperlink rather than \\phantomsection/\\label/\\hyperref:
    in Chirun's HTML several ``\\phantomsection\\label`` anchors in one paragraph collapse to a
    single URL, so every citation would jump to the *last* reference. ``\\hypertarget`` gives
    each entry its own named anchor. Only entries actually listed in References are linked."""
    m = _REF_HEADING_RE.search(body)
    if not m:
        return body  # nothing to link to -- leave citations as plain text
    cut = m.end()
    text, refs = body[:cut], body[cut:]
    listed = set(_CITE_RE.findall(refs))
    if not listed:
        return body
    refs = _CITE_RE.sub(
        lambda mm: f"\\hypertarget{{ref:{mm.group(1)}}}{{[{mm.group(1)}]}}", refs)

    def link(mm: re.Match) -> str:
        k = mm.group(1)
        return f"\\hyperlink{{ref:{k}}}{{[{k}]}}" if k in listed else mm.group(0)
    text = _CITE_RE.sub(link, text)
    return text + refs


def _number_floats(body: str) -> Tuple[str, dict]:
    """Anchor each figure/table caption label ("Figure 2") with a ``\\hypertarget`` and record
    the numbers seen per kind. Returns the new body and ``{'fig': {...}, 'tab': {...}}`` so
    mentions can be linked only where a matching float exists. Author numbers are preserved."""
    word_to_prefix = {word: prefix for word, prefix in _FLOAT_KINDS}
    keyed: dict = {prefix: set() for _, prefix in _FLOAT_KINDS}

    def repl(m: re.Match) -> str:
        cap = m.group("body")
        pre = re.search(r"\\hypertarget\{(?P<pfx>fig|tab):(?P<num>\d+)\}", cap)
        if pre:                              # caption already anchored (source pre-linked) -> keep,
            keyed[pre.group("pfx")].add(pre.group("num"))  # just record the number so mentions link
            return m.group(0)
        lbl = _CAP_LABEL_RE.search(cap)      # the leading "Figure N" / "Table N" label
        if not lbl:
            return m.group(0)
        prefix = word_to_prefix[lbl.group("word")]
        num = lbl.group("num")
        keyed[prefix].add(num)
        anchor = (f"\\hypertarget{{{prefix}:{num}}}"
                  f"{{{lbl.group('word')}{lbl.group('sp')}{num}}}")
        new_cap = cap[:lbl.start()] + anchor + cap[lbl.end():]
        return m.group("open") + new_cap + m.group("close")

    return _CAPTION_RE.sub(repl, body), keyed


def _link_float_refs(body: str, keyed: dict) -> str:
    """Turn "Figure 2" (and each number in "Figures 1 and 2") into a \\hyperlink to its
    caption anchor, keeping the word plain and linking the number -- exactly as equation
    mentions keep "Equation" plain and link "(k)". Only linked where the float exists."""
    def prefix_of(word: str) -> str:
        return "fig" if word.lower().startswith("fig") else "tab"

    def first(m: re.Match) -> str:
        prefix = prefix_of(m.group("word"))
        num = m.group("num")
        if num not in keyed.get(prefix, ()):
            return m.group(0)
        return f"{m.group('word')}{m.group('sp')}\\hyperlink{{{prefix}:{num}}}{{{num}}}"
    body = _FIGREF_WORD_RE.sub(first, body)

    def chain(m: re.Match) -> str:
        prefix, num = m.group("pfx"), m.group("num")
        if num not in keyed.get(prefix, ()):
            return m.group(0)
        return f"{m.group('prev')}{m.group('sep')}\\hyperlink{{{prefix}:{num}}}{{{num}}}"
    prev = None
    while prev != body:            # repeat so "1, 2 and 4" fully resolves
        prev = body
        body = _FIGREF_CHAIN_RE.sub(chain, body)
    return body


def apply(body: str) -> str:
    """Run the full cross-referencing pass on a document body."""
    store: List[str] = []                          # one shared sentinel namespace
    body = _mask(body, _COMMENT_RE, store)         # 1. protect comments from every pass
    body, keyed = _number_equations(body)          # 2. number equations (comments are safe)
    body, fig_keyed = _number_floats(body)         #    anchor figure/table caption labels
    body = _mask(body, _PROTECT_RE, store)         # 3. protect maths / alt-text / captions / URLs
    body = _link_equation_refs(body, keyed)        # 4. link mentions + citations (plain text
    body = _link_float_refs(body, fig_keyed)       #    only -- captions are masked, so a
    body = _link_citations(body)                   #    caption's own label is never re-linked)
    body = _unmask(body, store)                    # 5. restore everything
    return body
