"""Load the raw LaTeX source for a request.

The tool is LaTeX-only: the CLI has already resolved the input to a single ``.tex``
file (from an experiment folder or a file path), so all this does is read it.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .models import PrepRequest

_TEX_SUFFIXES = {".tex", ".latex"}


@dataclass
class RawInput:
    path: Path
    text: str


def load(req: PrepRequest) -> RawInput:
    if not req.input_path.exists():
        raise FileNotFoundError(f"Input file not found: {req.input_path}")
    if req.input_path.suffix.lower() not in _TEX_SUFFIXES:
        raise ValueError(
            f"Expected a .tex file, got '{req.input_path.name}'. chirunify takes LaTeX input.")
    return RawInput(req.input_path, req.input_path.read_text(encoding="utf-8"))
