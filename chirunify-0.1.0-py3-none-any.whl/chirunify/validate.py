"""Lint a Chirun package (a .tex string + its config dict) against the house rules.

Deliberately self-contained: it re-derives figures/packages from the .tex text so the
`chirunify check` command can lint an *existing* hand-made package, not just our output.
"""

from __future__ import annotations

import re
from typing import List, Optional

from . import macros
from .models import Issue, Severity

def mask_comments(text: str) -> str:
    """Blank out LaTeX comments (unescaped % to end of line) while preserving length and
    newlines, so structural scans aren't fooled by tokens mentioned in comments."""
    out = []
    for line in text.splitlines(keepends=True):
        i = 0
        commented = False
        while i < len(line):
            ch = line[i]
            if ch == "%" and (i == 0 or line[i - 1] != "\\"):
                commented = True
                break
            i += 1
        if commented:
            stripped = line[i:]
            newline = "\n" if stripped.endswith("\n") else ""
            out.append(line[:i] + " " * (len(stripped) - len(newline)) + newline)
        else:
            out.append(line)
    return "".join(out)


_USEPACKAGE_RE = re.compile(r"\\usepackage(?:\[[^\]]*\])?\{([^}]+)\}")
_HYPERREF_USE_RE = re.compile(r"\\hyper(?:ref|link|target)\b")
# An \includegraphics/\includesvg of an .svg file, capturing (options, path).
_SVG_INCLUDE_RE = re.compile(
    r"\\include(?:graphics|svg)(\[[^\]]*\])?\{([^}]+\.svg)\}", re.IGNORECASE)


def _option_keys(opts: str) -> set:
    """Keys present in an option list like ``[width=5cm,scale=0.5]`` -> {'width', 'scale'}."""
    inner = opts.strip()
    if inner.startswith("[") and inner.endswith("]"):
        inner = inner[1:-1]
    return {kv.split("=", 1)[0].strip() for kv in inner.split(",") if kv.strip()}
_INCLUDEGRAPHICS_RE = re.compile(r"\\include(?:graphics|svg)(?:\[[^\]]*\])?\{([^}]+)\}")
_DOC_RE = re.compile(r"\\begin\{document\}(.*)\\end\{document\}", re.DOTALL)
_DOCTITLE_RE = re.compile(r"\\doctitle\{([^}]*)\}")


def _document_body(tex: str) -> str:
    """Only the body -- so preamble constructs (e.g. \\penicon's own \\includegraphics)
    are never mistaken for content figures."""
    m = _DOC_RE.search(tex)
    return m.group(1) if m else tex


def _line_of(tex: str, index: int) -> int:
    return tex.count("\n", 0, index) + 1


def _config_source(config: dict) -> Optional[str]:
    structure = config.get("structure") or []
    for item in structure:
        if isinstance(item, dict) and item.get("source"):
            return item["source"]
    return None


def check_chirun_first(tex: str) -> List[Issue]:
    m = _USEPACKAGE_RE.search(tex)
    if not m:
        return [Issue(Severity.ERROR, "CHIRUN-FIRST",
                      "No \\usepackage found; expected \\usepackage[...]{chirun} first.")]
    first = m.group(1).strip()
    if "chirun" not in [p.strip() for p in first.split(",")]:
        return [Issue(Severity.ERROR, "CHIRUN-FIRST",
                      f"First package is '{first}', but \\usepackage[...]{{chirun}} "
                      "must be loaded first.",
                      location=f"line {_line_of(tex, m.start())}")]
    return []


def _pdf_only_spans(tex: str) -> List[range]:
    """Character ranges that sit inside an \\ifpdflatex ... \\fi block."""
    spans: List[range] = []
    stack: List[tuple] = []  # (kind, start_index)
    token_re = re.compile(r"\\(ifpdflatex|ifplastex|fi)\b")
    for m in token_re.finditer(tex):
        kind = m.group(1)
        if kind in ("ifpdflatex", "ifplastex"):
            stack.append((kind, m.end()))
        elif kind == "fi" and stack:
            open_kind, open_end = stack.pop()
            if open_kind == "ifpdflatex":
                spans.append(range(open_end, m.start()))
    return spans


def _in_pdf_only(index: int, spans: List[range]) -> bool:
    return any(index in span for span in spans)


def check_packages(tex: str) -> List[Issue]:
    issues: List[Issue] = []
    pdf_spans = _pdf_only_spans(tex)
    for m in _USEPACKAGE_RE.finditer(tex):
        names = [p.strip() for p in m.group(1).split(",")]
        if _in_pdf_only(m.start(), pdf_spans):
            continue  # PDF-only packages never reach plasTeX
        loc = f"line {_line_of(tex, m.start())}"
        for name in names:
            if name in macros.BANNED_PACKAGES:
                issues.append(Issue(Severity.WARN, "UNSUPPORTED-PACKAGE",
                    f"Package '{name}' is not supported by Chirun/plasTeX; move it inside "
                    "\\ifpdflatex or drop it.", loc))
            elif name not in macros.SUPPORTED_PACKAGES:
                issues.append(Issue(Severity.WARN, "UNSUPPORTED-PACKAGE",
                    f"Package '{name}' is not on the known-good list; verify it builds in "
                    "Chirun, or move it inside \\ifpdflatex.", loc))
    return issues


def check_hyperref_loaded(tex: str) -> List[Issue]:
    """\\hyperref/\\hyperlink/\\hypertarget need hyperref loaded for the HTML build. Chirun's
    plasTeX `chirun` package -- unlike chirun.sty in the PDF build -- does NOT load hyperref,
    so a bare \\hyperref crashes the build ("'dict object' has no attribute 'label'"). Require
    an explicit \\usepackage{hyperref} outside \\ifpdflatex wherever these are used there."""
    pdf_spans = _pdf_only_spans(tex)
    uses = [m for m in _HYPERREF_USE_RE.finditer(tex) if not _in_pdf_only(m.start(), pdf_spans)]
    if not uses:
        return []
    loaded = any(
        "hyperref" in [p.strip() for p in m.group(1).split(",")]
        and not _in_pdf_only(m.start(), pdf_spans)
        for m in _USEPACKAGE_RE.finditer(tex)
    )
    if loaded:
        return []
    return [Issue(Severity.ERROR, "HYPERREF-MISSING",
        "\\hyperref is used for the HTML build but hyperref is not loaded there. Chirun's "
        "plasTeX package does not auto-load it (chirun.sty only loads it for the PDF), so the "
        "build crashes. Add \\usepackage{hyperref} after \\usepackage[...]{chirun}.",
        location=f"line {_line_of(tex, uses[0].start())}")]


def check_figures_alttext(tex: str) -> List[Issue]:
    """Every body \\includegraphics should have an \\alttext in its enclosing block."""
    body = _document_body(tex)
    base = tex.find(body)
    issues: List[Issue] = []
    for m in _INCLUDEGRAPHICS_RE.finditer(body):
        block = _enclosing_block(body, m.start(), m.end())
        if "\\alttext" not in block:
            issues.append(Issue(Severity.ERROR, "FIGURE-NO-ALTTEXT",
                f"Figure '{m.group(1)}' has no \\alttext{{...}} -- required for accessible HTML.",
                location=f"line {_line_of(tex, base + m.start())}"))
    return issues


def check_svg(tex: str) -> List[Issue]:
    """SVG is what Chirun serves in the HTML (it stays crisp at any zoom): figures are authored
    with a raster ``\\includegraphics`` for a reliable Overleaf PDF, and chirunify swaps in the
    ``_SVG.svg`` redraw for the web. The one gotcha, once that SVG is in place: sizing it with
    ``scale=`` or ``keepaspectratio`` makes Chirun try to read the image's pixel size, which it
    can't do for a vector file -- the build crashes. Flag only that; plain ``width=``/``height=``
    is fine (and is what you should use)."""
    body = _document_body(tex)
    base = tex.find(body)
    issues: List[Issue] = []
    for m in _SVG_INCLUDE_RE.finditer(body):
        keys = _option_keys(m.group(1) or "")
        crashes = "scale" in keys or (
            "keepaspectratio" in keys and "width" in keys and "height" in keys)
        if crashes:
            issues.append(Issue(Severity.ERROR, "SVG-SIZE",
                f"SVG figure '{m.group(2)}' is sized with scale=/keepaspectratio; Chirun "
                "cannot read a vector image's pixel size, so the build will crash. Size it "
                "with width= or height= instead.",
                location=f"line {_line_of(tex, base + m.start())}"))
    return issues


_RAWURL_CMD_RE = re.compile(r"\\url\{[^{}]*\}|\\nolinkurl\{[^{}]*\}")
_HREF_TEXT_RE = re.compile(r"\\href\{([^{}]*)\}\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}")
_NOLINKURL_INNER_RE = re.compile(r"^\\nolinkurl\{([^{}]*)\}$")
_URLISH_RE = re.compile(r"^(?:https?://|www\.)", re.IGNORECASE)


def check_link_text(tex: str) -> List[Issue]:
    """Links must show descriptive text, not the raw address (WCAG 2.4.4): a screen
    reader otherwise reads the whole URL out, and it is meaningless in a link list.
    Flags \\url{}/\\nolinkurl{} and any \\href whose visible text is just the URL."""
    body = _document_body(tex)
    base = tex.find(body)
    issues: List[Issue] = []
    for m in _RAWURL_CMD_RE.finditer(body):
        issues.append(Issue(Severity.WARN, "URL-LINK-TEXT",
            f"'{m.group(0)}' shows a raw URL as the link text; wrap it as "
            "\\href{url}{descriptive text} so screen readers announce the destination, "
            "not the whole address.",
            location=f"line {_line_of(tex, base + m.start())}"))
    for m in _HREF_TEXT_RE.finditer(body):
        url, text = m.group(1), m.group(2).strip()
        inner = _NOLINKURL_INNER_RE.match(text)
        visible = inner.group(1).strip() if inner else text
        if visible and (_URLISH_RE.match(visible) or visible.rstrip("/") == url.rstrip("/")):
            issues.append(Issue(Severity.WARN, "URL-LINK-TEXT",
                f"\\href to {url} uses the URL itself as its link text; replace it with "
                "descriptive text so screen readers announce the destination.",
                location=f"line {_line_of(tex, base + m.start())}"))
    return issues


def check_source_clash(config: dict, actual_tex_filename: str) -> List[Issue]:
    source = _config_source(config)
    if source is None:
        return [Issue(Severity.ERROR, "SOURCE-CLASH",
                      "config.yml has no structure item with a 'source'.")]
    if source != actual_tex_filename:
        return [Issue(Severity.ERROR, "SOURCE-CLASH",
            f"config.yml 'source: {source}' does not match the actual file "
            f"'{actual_tex_filename}'. Chirun will report \"specified source does not exist\".")]
    return []


def check_title_mismatch(tex: str, config: dict) -> List[Issue]:
    m = _DOCTITLE_RE.search(tex)
    cfg_title = config.get("title")
    if m and cfg_title and m.group(1).strip() != str(cfg_title).strip():
        return [Issue(Severity.WARN, "TITLE-MISMATCH",
            f"\\doctitle '{m.group(1).strip()}' differs from config title '{cfg_title}'.")]
    return []


def _enclosing_block(body: str, start: int, end: int) -> str:
    for env in ("figure", "minipage"):
        open_ = body.rfind(r"\begin{%s}" % env, 0, start)
        close = body.find(r"\end{%s}" % env, end)
        if open_ != -1 and close != -1:
            return body[open_:close]
    return body[max(0, start - 400):min(len(body), end + 400)]


def run(tex: str, config: dict, actual_tex_filename: str) -> List[Issue]:
    """Run every rule and return the collected issues (ERRORs first)."""
    masked = mask_comments(tex)  # scan structure without comment interference
    issues: List[Issue] = []
    issues += check_chirun_first(masked)
    issues += check_packages(masked)
    issues += check_hyperref_loaded(masked)
    issues += check_figures_alttext(masked)
    issues += check_svg(masked)
    issues += check_link_text(masked)
    issues += check_source_clash(config, actual_tex_filename)
    issues += check_title_mismatch(masked, config)
    order = {Severity.ERROR: 0, Severity.WARN: 1, Severity.TODO: 2}
    issues.sort(key=lambda i: order[i.severity])
    return issues
