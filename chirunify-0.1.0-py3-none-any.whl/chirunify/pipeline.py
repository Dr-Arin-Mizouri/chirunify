"""The orchestrator. Deterministic and side-effect-free: it returns a PrepResult of
strings/objects; the CLI is responsible for reading/writing files. This is what lets a
future web UI or Claude-API layer reuse the exact same core (see interfaces.Enhancers)."""

from __future__ import annotations

import re
from typing import List, Optional

from . import config_gen, ingest, macros, normalize, preamble, validate
from .interfaces import Enhancers, default_enhancers
from .models import Document, Issue, PrepRequest, PrepResult, Severity, slugify


def _resolve_title(req: PrepRequest, doc: Document) -> str:
    if req.title:
        return req.title
    if doc.title:
        return doc.title
    return req.input_path.stem.replace("_", " ").strip().title()


def _apply_alt_text(doc: Document, enhancers: Enhancers) -> List[Issue]:
    """Seam for a future AI pass. In the MVP the provider returns None, so every figure
    without alt text stays a job for a human (validate raises FIGURE-NO-ALTTEXT)."""
    issues: List[Issue] = []
    for fig in doc.figures:
        if fig.has_alttext:
            continue
        suggestion = enhancers.alt_text.suggest(fig, doc.body)
        if suggestion:
            marker = re.escape(fig.path)
            doc.body = re.sub(
                r"(\\includegraphics(?:\[[^\]]*\])?\{" + marker + r"\})",
                r"\1\n\\alttext{" + suggestion.replace("\\", r"\\") + "}",
                doc.body, count=1)
            fig.has_alttext = True
    return issues


def _symbol_todos(doc: Document) -> List[Issue]:
    todos: List[Issue] = []
    for sym in doc.symbols:
        if sym in macros.KNOWN_SYMBOLS or sym in macros.EXTRA_SYMBOL_FALLBACKS:
            continue
        todos.append(Issue(Severity.TODO, "MISSING-SYMBOL-FALLBACK",
            f"Maths macro \\{sym} has only a stub fallback; give MathJax a real equivalent "
            "in the preamble \\providecommand block."))
    return todos


def run_pipeline(req: PrepRequest, enhancers: Optional[Enhancers] = None) -> PrepResult:
    enhancers = enhancers or default_enhancers()
    raw = ingest.load(req)

    doc = normalize.normalize(raw.text, req.media_dir)

    title = _resolve_title(req, doc)
    slug = req.slug or slugify(title)

    extra_issues = _apply_alt_text(doc, enhancers)
    extra_issues += _symbol_todos(doc)

    tex = preamble.render(doc.body, title, doc.symbols,
                          doc.reflection_title or "Points for consideration")
    config = config_gen.build(title, slug, req.author, req.build_pdf)

    issues = validate.run(tex, config, f"{slug}.tex") + doc.issues + extra_issues
    order = {Severity.ERROR: 0, Severity.WARN: 1, Severity.TODO: 2}
    issues.sort(key=lambda i: order[i.severity])

    return PrepResult(slug=slug, title=title, tex=tex, config=config,
                      issues=issues, figures=doc.figures)
