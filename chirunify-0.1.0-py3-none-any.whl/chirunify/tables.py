"""Rewrite simple data tables so Chirun emits *accessible* HTML tables.

Chirun/plasTeX renders every LaTeX ``tabular`` cell as ``<td>`` and never marks header cells,
so a screen reader can't tie a value to its column header (no <th>/scope). plasTeX can't be
made to emit ``<th>`` from any tabular construct. But the chirun package offers a raw-HTML
passthrough -- ``\\begin{HTML}...\\end{HTML}`` (HTML build only; nothing in the PDF). So for a
table we can parse confidently we replace ``\\begin{tabular}...\\end{tabular}`` with::

    \\ifplastex \\begin{HTML}<accessible html table>\\end{HTML} \\else <original tabular> \\fi

The HTML mirrors Chirun's own table markup (``class="tabular"``, per-cell ``text-align`` and the
post-\\hline top border) but promotes the bold header row to ``<thead>`` / ``<th scope="col">``
-- the header-to-cell association assistive tech needs (WCAG 1.3.1). The PDF branch keeps the
original tabular untouched. This runs inside ``chirunify build``; the author's source .tex and
the conversion guide are unchanged.

Conservative (SKILL.md: never silently transform the uncertain): only a *simple* grid with an
all-bold first row is converted. A table with ``\\multicolumn``/``\\multirow``, a nested tabular
or ragged rows is left exactly as-is and flagged with a TODO; a table with no bold header row is
left as-is silently (it has no header to mark). Cell maths (``$...$``) is converted to
MathJax-native form -- ``\\symup``->``\\mathrm`` etc. -- since plasTeX does not expand macros
inside a raw-HTML block.
"""

from __future__ import annotations

import re
from typing import List, Tuple

from .models import Issue, Severity

# A tabular, capturing its column spec (one level of nested braces, for p{width}) and body.
_TABULAR_RE = re.compile(
    r"\\begin\{tabular\}\s*(?:\[[^\]]*\]\s*)?"
    r"\{(?P<spec>(?:[^{}]|\{[^{}]*\})*)\}"
    r"(?P<body>.*?)\\end\{tabular\}",
    re.DOTALL,
)
_ROW_SPLIT_RE = re.compile(r"\\\\(?:\s*\[[^\]]*\])?")          # \\ or \\[2pt] row separator
_RULE_RE = re.compile(r"\\(?:hline|toprule|midrule|bottomrule)\b|\\cline\{[^}]*\}")
_BOLD_RE = re.compile(r"\\bfseries|\\textbf|\\symbfup|\\symbf")
# \symX{..} maths macros -> their MathJax-native equivalents (the same fallbacks the preamble
# provides; applied here because a raw-HTML block is NOT processed by plasTeX). \b avoids
# \symbf matching \symbfup.
_MATH_MACRO_SUBST: List[Tuple[re.Pattern, str]] = [
    (re.compile(r"\\symbfup\b"), r"\\mathbf"),
    (re.compile(r"\\symbf\b"), r"\\boldsymbol"),
    (re.compile(r"\\symup\b"), r"\\mathrm"),
    (re.compile(r"\\symsf\b"), r"\\mathsf"),
    (re.compile(r"\\symit\b"), r"\\mathit"),
    (re.compile(r"\\symbb\b"), r"\\mathbb"),
    (re.compile(r"\\smblksquare\b"), r"\\blacksquare"),
    (re.compile(r"\\smwhtsquare\b"), r"\\square"),
]
_FMT_UNWRAP_RE = re.compile(r"\\(?:textbf|textit|texttt|textsf|textrm|emph|text)\{([^{}]*)\}")
_FMT_STRIP_RE = re.compile(
    r"\\(?:headingfont|headerfont|bfseries|mdseries|itshape|upshape|slshape|scshape|"
    r"normalfont|selectfont|centering|raggedright|raggedleft|tiny|scriptsize|footnotesize|"
    r"small|normalsize|large|Large|LARGE)\b\s*")


def _convert_math(inner: str) -> str:
    """Body of a ``$...$`` -> a MathJax ``\\(...\\)`` with \\symX macros mapped to natives."""
    for pat, repl in _MATH_MACRO_SUBST:
        inner = pat.sub(repl, inner)
    return r"\(" + inner.strip() + r"\)"


def _text_html(text: str) -> str:
    """A non-maths run of cell text -> HTML: drop LaTeX formatting, resolve escapes, HTML-escape."""
    text = _FMT_UNWRAP_RE.sub(r"\1", text)      # \textbf{X} -> X
    text = _FMT_STRIP_RE.sub("", text)          # drop \bfseries \headingfont ... (bare)
    text = text.replace("{", "").replace("}", "")
    text = text.replace("~", " ")           # LaTeX ~ = non-breaking space
    text = re.sub(r"\\([&%_#$])", r"\1", text)   # \& \% \_ \# \$ -> literal
    text = text.replace("---", "—").replace("--", "–")
    text = re.sub(r"\s+", " ", text)
    text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return text


def _cell_html(cell: str) -> str:
    """One cell's LaTeX -> HTML content (maths kept as MathJax \\(...\\), text cleaned/escaped)."""
    out: List[str] = []
    for part in re.split(r"(\$[^$]*\$)", cell.strip()):
        if len(part) >= 2 and part.startswith("$") and part.endswith("$"):
            out.append(_convert_math(part[1:-1]))
        elif part:
            out.append(_text_html(part))
    return "".join(out).strip()


def _split_cells(row: str) -> List[str]:
    """Split a row on the column separator ``&`` -- ignoring ``\\&``, and ``&`` inside {} or $ $."""
    cells: List[str] = []
    buf: List[str] = []
    depth = 0
    in_math = False
    i = 0
    while i < len(row):
        c = row[i]
        if c == "\\" and i + 1 < len(row):
            buf.append(row[i:i + 2])
            i += 2
            continue
        if c == "$":
            in_math = not in_math
        elif c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
        elif c == "&" and depth == 0 and not in_math:
            cells.append("".join(buf).strip())
            buf = []
            i += 1
            continue
        buf.append(c)
        i += 1
    cells.append("".join(buf).strip())
    return cells


def _parse_rows(body: str) -> List[Tuple[List[str], bool]]:
    """Parse a tabular body into ``[(cells, has_top_border), ...]``. A row has a top border when
    a horizontal rule (``\\hline`` etc.) precedes it -- mirroring how Chirun renders \\hline."""
    rows: List[Tuple[List[str], bool]] = []
    for segment in _ROW_SPLIT_RE.split(body):
        s = segment.strip()
        border = False
        while True:                                  # peel leading rule commands
            m = _RULE_RE.match(s)
            if not m:
                break
            border = True
            s = s[m.end():].strip()
        if not s:                                    # a rule-only / blank segment: no row
            continue
        rows.append((_split_cells(s), border))
    return rows


def _alignments(spec: str) -> List[str]:
    spec = re.sub(r"@\{[^}]*\}|>\{[^}]*\}|<\{[^}]*\}|\|", "", spec)
    aligns: List[str] = []
    for m in re.finditer(r"[clr]|[pmb]\{[^}]*\}", spec):
        tok = m.group(0)[0]
        aligns.append({"c": "center", "l": "left", "r": "right"}.get(tok, "left"))
    return aligns


def _build_html(aligns: List[str], header: List[str],
                data_rows: List[Tuple[List[str], bool]]) -> str:
    def align(i: int) -> str:
        return aligns[i] if i < len(aligns) else "left"

    ths = "".join(
        f'<th scope="col" style="text-align:{align(i)}"><p>{_cell_html(c)}</p></th>'
        for i, c in enumerate(header))
    trs: List[str] = []
    for cells, border in data_rows:
        tds: List[str] = []
        for i, c in enumerate(cells):
            style = f"text-align:{align(i)}"
            if border:
                style = ("border-top-style:solid; border-top-color:black; "
                         "border-top-width:1px; ") + style
            tds.append(f'<td style="{style}"><p>{_cell_html(c)}</p></td>')
        trs.append("<tr>" + "".join(tds) + "</tr>")
    return ('<table class="tabular">\n<thead>\n<tr>' + ths + "</tr>\n</thead>\n<tbody>\n"
            + "\n".join(trs) + "\n</tbody>\n</table>")


def _dual_mode(html: str, original_tabular: str) -> str:
    return (f"\\ifplastex\n\\begin{{HTML}}\n{html}\n\\end{{HTML}}\n"
            f"\\else\n{original_tabular}\n\\fi")


def rewrite(body: str) -> Tuple[str, List[Issue]]:
    """Replace each convertible data table with the dual-mode accessible-HTML form. Returns the
    new body and any TODOs for tables too complex to convert safely."""
    issues: List[Issue] = []

    def repl(m: re.Match) -> str:
        whole = m.group(0)
        if re.search(r"\\multicolumn|\\multirow", whole) or "\\begin{tabular}" in m.group("body"):
            issues.append(Issue(Severity.TODO, "TABLE-A11Y",
                "A data table uses \\multicolumn/\\multirow or is nested, so it was left as a "
                "plain tabular -- its header cells won't be marked <th> for screen readers. "
                "Simplify it, or mark the table up by hand for accessibility."))
            return whole
        rows = _parse_rows(m.group("body"))
        if len(rows) < 2:
            return whole                                     # header-only / empty: leave
        header_cells, _ = rows[0]
        if not header_cells or not all(_BOLD_RE.search(c) for c in header_cells):
            return whole                                     # no bold header row: leave (renders natively)
        data_rows = rows[1:]
        ncol = len(header_cells)
        if any(len(cells) != ncol for cells, _ in data_rows):
            issues.append(Issue(Severity.TODO, "TABLE-A11Y",
                "A data table has rows with differing cell counts, so it was left as a plain "
                "tabular (not converted to an accessible HTML table) -- check the table's "
                "structure and header markup by hand."))
            return whole
        html = _build_html(_alignments(m.group("spec")), header_cells, data_rows)
        return _dual_mode(html, whole)

    return _TABULAR_RE.sub(repl, body), issues