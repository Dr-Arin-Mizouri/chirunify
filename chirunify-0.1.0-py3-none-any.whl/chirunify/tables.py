"""Rewrite simple data tables so Chirun emits *accessible* HTML tables.

Chirun/plasTeX renders every LaTeX ``tabular`` cell as ``<td>`` and never marks header cells,
so a screen reader can't tie a value to its column header (no <th>/scope). plasTeX can't be
made to emit ``<th>`` from any tabular construct. But the chirun package offers a raw-HTML
passthrough -- ``\\begin{HTML}...\\end{HTML}`` (HTML build only; nothing in the PDF). So for a
table we can parse confidently we replace ``\\begin{tabular}...\\end{tabular}`` with::

    \\begin{HTML}<accessible html table>\\end{HTML} \\ifplastex\\else <original tabular> \\fi

(The ``\\begin{HTML}`` block sits OUTSIDE ``\\ifplastex`` -- nesting this verbatim environment in
a conditional branch derails plasTeX's ``\\else``/``\\fi`` and environment matching, so the
enclosing float's ``\\end{table}`` leaks and the rest of the document renders raw. The HTML env
is HTML-only by itself: ``chirun.sty`` does ``\\excludecomment{HTML}`` for the PDF build.)

The HTML mirrors Chirun's own table markup (``class="tabular"``, per-cell ``text-align`` and the
post-\\hline top border) but promotes the bold header row to ``<thead>`` / ``<th scope="col">``
-- the header-to-cell association assistive tech needs (WCAG 1.3.1). The PDF branch keeps the
original tabular untouched. This runs inside ``chirunify build``; the author's source .tex and
the conversion guide are unchanged.

Cell maths becomes plain text/HTML, NOT LaTeX/MathJax. Chirun's ``HTML`` environment does
*not* capture its body verbatim -- it parses it -- so any math shift (``\\(`` or ``$``) or
backslash command left inside the block becomes a non-text node and Chirun crashes joining
the block ("sequence item N: expected str instance, math found"). So we render cell maths to
Unicode text with ``<sub>``/``<sup>`` (e.g. ``$\\symup{kg}$`` -> ``kg``, ``$R_{1}$`` ->
``R<sub>1</sub>``, ``$90^{\\circ}$`` -> ``90&#176;``). For a units/numbers data table this is
also the cleaner screen-reader reading. The converter is a *whitelist*: if a cell holds maths
(or text) with a command it doesn't recognise, the cell is "unconvertible" and the whole
table is left as a native tabular and flagged -- we never emit a backslash or ``$`` into the
HTML block (a final guard in ``rewrite`` enforces this).

Conservative (SKILL.md: never silently transform the uncertain): only a *simple* grid with an
all-bold first row is converted. A table with ``\\multicolumn``/``\\multirow``, a nested tabular,
ragged rows, or cell maths we can't render safely is left exactly as-is and flagged with a
TODO; a table with no bold header row is left as-is silently (it has no header to mark).
"""

from __future__ import annotations

import re
from typing import List, Optional, Tuple

from .models import Issue, Severity

# A tabular, capturing its column spec (one level of nested braces, for p{width}) and body.
_TABULAR_RE = re.compile(
    r"\\begin\{tabular\}\s*(?:\[[^\]]*\]\s*)?"
    r"\{(?P<spec>(?:[^{}]|\{[^{}]*\})*)\}"
    r"(?P<body>.*?)\\end\{tabular\}",
    re.DOTALL,
)
_ROW_SPLIT_RE = re.compile(r"\\\\(?:\s*\[[^\]]*\])?")          # \\ or \\[2pt] row separator
_RULE_RE = re.compile(r"\\(?:hline|toprule|midrule|bottomrule)\b|\\cline\{[^}]*\}")
_BOLD_RE = re.compile(r"\\bfseries|\\textbf|\\symbfup|\\symbf")

# ------------------------------------------------------------------------------------------
# Cell LaTeX (text + maths) -> plain HTML text. The chirun HTML environment PARSES its body,
# so the emitted block must contain no backslash command and no math shift. ``_render`` walks
# a cell once (brace-aware, math-aware) and produces Unicode + <sub>/<sup>; any construct it
# doesn't recognise makes the cell unconvertible (returns None) and the table is then left
# native. See module docstring.

# bare formatting commands to drop (they carry no content)
_BARE = {
    "headingfont", "headerfont", "bfseries", "mdseries", "itshape", "upshape", "slshape",
    "scshape", "normalfont", "selectfont", "centering", "raggedright", "raggedleft", "tiny",
    "scriptsize", "footnotesize", "small", "normalsize", "large", "Large", "LARGE",
    "boldmath", "unboldmath", "noindent", "displaystyle", "textstyle", "scriptstyle",
}
# wrappers whose single braced argument is content we keep (recurse into it)
_WRAP = {
    "symup", "symbf", "symbfup", "symsf", "symit", "symbb", "symrm", "symnormal",
    "mathrm", "mathbf", "mathit", "mathsf", "mathbb", "mathnormal", "boldsymbol",
    "mathord", "mathbin", "mathrel", "mathstrut",
    "text", "textbf", "textit", "textrm", "textsf", "texttt", "textnormal", "emph",
    "operatorname", "mbox", "hbox",
}
_SPACE_CMD = {" ": " ", ",": " ", ";": " ", ":": " ", "!": "", "quad": " ", "qquad": " ",
              "enspace": " ", "thinspace": " ", "space": " "}
_ESC_CMD = {"%": "%", "&": "&", "_": "_", "#": "#", "$": "$", "{": "{", "}": "}"}
_SYM = {
    "alpha": "α", "beta": "β", "gamma": "γ", "delta": "δ", "epsilon": "ε", "varepsilon": "ε",
    "zeta": "ζ", "eta": "η", "theta": "θ", "vartheta": "θ", "iota": "ι", "kappa": "κ",
    "lambda": "λ", "mu": "µ", "nu": "ν", "xi": "ξ", "omicron": "ο", "pi": "π", "varpi": "ϖ",
    "rho": "ρ", "varrho": "ρ", "sigma": "σ", "varsigma": "ς", "tau": "τ", "upsilon": "υ",
    "phi": "φ", "varphi": "φ", "chi": "χ", "psi": "ψ", "omega": "ω",
    "Gamma": "Γ", "Delta": "Δ", "Theta": "Θ", "Lambda": "Λ", "Xi": "Ξ", "Pi": "Π",
    "Sigma": "Σ", "Upsilon": "Υ", "Phi": "Φ", "Psi": "Ψ", "Omega": "Ω",
    "times": "×", "cdot": "·", "div": "÷", "pm": "±", "mp": "∓", "ast": "*", "star": "⋆",
    "leq": "≤", "le": "≤", "geq": "≥", "ge": "≥", "ll": "≪", "gg": "≫", "neq": "≠", "ne": "≠",
    "approx": "≈", "sim": "∼", "simeq": "≃", "cong": "≅", "equiv": "≡", "propto": "∝",
    "infty": "∞", "circ": "°", "degree": "°", "deg": "°", "prime": "′", "angle": "∠",
    "rightarrow": "→", "to": "→", "leftarrow": "←", "Rightarrow": "⇒", "Leftarrow": "⇐",
    "leftrightarrow": "↔", "ldots": "…", "dots": "…", "cdots": "…", "bullet": "•",
    "partial": "∂", "nabla": "∇", "hbar": "ℏ", "ell": "ℓ", "perp": "⊥", "parallel": "∥",
    "smblksquare": "■", "smwhtsquare": "□", "blacksquare": "■", "square": "□",
    "blacktriangleright": "▶", "sum": "∑", "int": "∫", "sqrt": "√",
}
_CMD_RE = re.compile(r"\\([A-Za-z]+|.)", re.DOTALL)


def _esc(ch: str) -> str:
    return {"<": "&lt;", ">": "&gt;", "&": "&amp;"}.get(ch, ch)


def _grab_group(s: str, i: int) -> Tuple[Optional[str], int]:
    """If ``s[i]`` opens a ``{...}`` group, return (inner, index-after-``}``); else (None, i)."""
    if i >= len(s) or s[i] != "{":
        return None, i
    depth, j = 0, i
    while j < len(s):
        if s[j] == "{":
            depth += 1
        elif s[j] == "}":
            depth -= 1
            if depth == 0:
                return s[i + 1:j], j + 1
        j += 1
    return None, i                                            # unbalanced


def _grab_arg(s: str, i: int) -> Tuple[Optional[str], int]:
    """A macro / sub / sup argument: a ``{group}`` or a single token (a char, or ``\\cmd``)."""
    inner, j = _grab_group(s, i)
    if inner is not None:
        return inner, j
    if i < len(s) and s[i] == "\\":
        m = _CMD_RE.match(s, i)
        if m:
            return m.group(0), m.end()
    if i < len(s):
        return s[i], i + 1
    return None, i


def _render(s: str, math: bool) -> Optional[str]:
    """Render a cell fragment (``math`` = inside ``$...$``) to plain HTML text (Unicode +
    <sub>/<sup>). Returns None on any construct it can't render safely -- so the caller leaves
    the table native rather than emit a backslash / ``$`` that would crash Chirun's HTML parse.
    Text and maths share this walker: ``$`` switches into maths (where ``_``/``^`` become
    <sub>/<sup>), and formatting wrappers (\\textbf, \\symup, ...) unwrap in either mode."""
    out: List[str] = []
    i, n = 0, len(s)
    while i < n:
        c = s[i]
        if c == "\\":
            m = _CMD_RE.match(s, i)
            if not m:
                return None
            name, i = m.group(1), m.end()
            if name in _BARE:
                while i < n and s[i] == " ":                 # eat the command's trailing space
                    i += 1
            elif name in _SPACE_CMD:
                out.append(_SPACE_CMD[name])
            elif name in _ESC_CMD:
                out.append(_esc(_ESC_CMD[name]))
            elif name in ("sqrt", "overline", "bar", "widehat", "hat", "vec",
                          "frac", "dfrac", "tfrac", "cfrac"):
                arg, i = _grab_arg(s, i)
                inner = _render(arg, math) if arg is not None else None
                if inner is None:
                    return None
                if name == "sqrt":
                    out.append("√" + inner)
                elif name in ("frac", "dfrac", "tfrac", "cfrac"):
                    arg2, i = _grab_arg(s, i)
                    inner2 = _render(arg2, math) if arg2 is not None else None
                    if inner2 is None:
                        return None
                    out.append(inner + "/" + inner2)
                else:                                        # overline/bar/hat/vec -> combining bar
                    out.append(inner + "̅")
            elif name in _WRAP:
                arg, i = _grab_arg(s, i)
                inner = _render(arg, math) if arg is not None else None
                if inner is None:
                    return None
                out.append(inner)
            elif name in _SYM:
                out.append(_SYM[name])
            else:
                return None                                  # unrecognised command
            continue
        if c == "{":
            inner_s, i = _grab_group(s, i)
            inner = _render(inner_s, math) if inner_s is not None else None
            if inner is None:
                return None
            out.append(inner)
            continue
        if c == "}":
            return None
        if c == "$":
            if math:                                         # nested / unbalanced math
                return None
            j = s.find("$", i + 1)
            if j < 0:
                return None
            inner = _render(s[i + 1:j], True)
            if inner is None:
                return None
            out.append(inner)
            i = j + 1
            continue
        if c == "&":                                         # bare alignment tab inside a cell
            return None
        if math and c in "_^":
            arg, i = _grab_arg(s, i + 1)
            inner = _render(arg, math) if arg is not None else None
            if inner is None:
                return None
            if c == "^" and inner == "°":                    # ^{\circ} is a degree sign, not a script
                out.append("°")
            else:
                tag = "sub" if c == "_" else "sup"
                out.append(f"<{tag}>{inner}</{tag}>")
            continue
        if c == "~":
            out.append(" ")
            i += 1
            continue
        out.append(" " if c.isspace() else _esc(c))
        i += 1
    text = "".join(out)
    if not math:
        text = text.replace("---", "—").replace("--", "–")
    return re.sub(r"\s+", " ", text)


def _cell_html(cell: str) -> Optional[str]:
    """One cell's LaTeX -> plain HTML content, or None if any part can't be rendered safely."""
    rendered = _render(cell.strip(), math=False)
    return rendered.strip() if rendered is not None else None


def _split_cells(row: str) -> List[str]:
    """Split a row on the column separator ``&`` -- ignoring ``\\&``, and ``&`` inside {} or $ $."""
    cells: List[str] = []
    buf: List[str] = []
    depth = 0
    in_math = False
    i = 0
    while i < len(row):
        c = row[i]
        if c == "\\" and i + 1 < len(row):
            buf.append(row[i:i + 2])
            i += 2
            continue
        if c == "$":
            in_math = not in_math
        elif c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
        elif c == "&" and depth == 0 and not in_math:
            cells.append("".join(buf).strip())
            buf = []
            i += 1
            continue
        buf.append(c)
        i += 1
    cells.append("".join(buf).strip())
    return cells


def _parse_rows(body: str) -> List[Tuple[List[str], bool]]:
    """Parse a tabular body into ``[(cells, has_top_border), ...]``. A row has a top border when
    a horizontal rule (``\\hline`` etc.) precedes it -- mirroring how Chirun renders \\hline."""
    rows: List[Tuple[List[str], bool]] = []
    for segment in _ROW_SPLIT_RE.split(body):
        s = segment.strip()
        border = False
        while True:                                  # peel leading rule commands
            m = _RULE_RE.match(s)
            if not m:
                break
            border = True
            s = s[m.end():].strip()
        if not s:                                    # a rule-only / blank segment: no row
            continue
        rows.append((_split_cells(s), border))
    return rows


def _alignments(spec: str) -> List[str]:
    spec = re.sub(r"@\{[^}]*\}|>\{[^}]*\}|<\{[^}]*\}|\|", "", spec)
    aligns: List[str] = []
    for m in re.finditer(r"[clr]|[pmb]\{[^}]*\}", spec):
        tok = m.group(0)[0]
        aligns.append({"c": "center", "l": "left", "r": "right"}.get(tok, "left"))
    return aligns


def _build_html(aligns: List[str], header: List[str],
                data_rows: List[Tuple[List[str], bool]]) -> Optional[str]:
    """Build the accessible HTML table, or None if any cell can't be rendered safely as text."""
    def align(i: int) -> str:
        return aligns[i] if i < len(aligns) else "left"

    hcells = [_cell_html(c) for c in header]
    if any(h is None for h in hcells):
        return None
    ths = "".join(
        f'<th scope="col" style="text-align:{align(i)}">{h}</th>'
        for i, h in enumerate(hcells))
    trs: List[str] = []
    for cells, border in data_rows:
        tds: List[str] = []
        for i, c in enumerate(cells):
            cc = _cell_html(c)
            if cc is None:
                return None
            style = f"text-align:{align(i)}"
            if border:
                style = ("border-top-style:solid; border-top-color:black; "
                         "border-top-width:1px; ") + style
            tds.append(f'<td style="{style}">{cc}</td>')
        trs.append("<tr>" + "".join(tds) + "</tr>")
    # NB: do NOT put class="tabular" on this table. Chirun's theme sets
    # `.tabular { display: inline-block }`, and overriding a <table>'s display strips its
    # table semantics from the accessibility tree (WebKit/VoiceOver stops treating the
    # <th scope="col"> cells as headers). Keeping it a native table (display:table) is what
    # makes the header association actually reach a screen reader. width:auto/margin:auto
    # give the shrink-to-fit, centred look .tabular used to provide (the enclosing
    # .centered div centres via text-align, which only worked on the inline-block).
    return ('<table style="width:auto; margin:auto; border-collapse:collapse">\n'
            '<thead>\n<tr>' + ths + "</tr>\n</thead>\n<tbody>\n"
            + "\n".join(trs) + "\n</tbody>\n</table>")


def _dual_mode(html: str, original_tabular: str) -> str:
    # \begin{HTML} must sit OUTSIDE \ifplastex. It's a verbatim environment, and nesting it in
    # a conditional's branch breaks plasTeX's \else/\fi + environment matching -- the enclosing
    # float's \end{table} then leaks and the rest of the document renders as raw LaTeX. The HTML
    # environment is inherently HTML-only (chirun.sty does \excludecomment{HTML} for the PDF
    # build), so the block simply vanishes in the PDF; only the PDF tabular needs the guard,
    # as \ifplastex\else ... \fi (rendered only when NOT plasTeX).
    return (f"\\begin{{HTML}}\n{html}\n\\end{{HTML}}\n"
            f"\\ifplastex\\else\n{original_tabular}\n\\fi")


def rewrite(body: str) -> Tuple[str, List[Issue]]:
    """Replace each convertible data table with the dual-mode accessible-HTML form. Returns the
    new body and any TODOs for tables too complex to convert safely."""
    issues: List[Issue] = []

    def _todo(msg: str) -> None:
        issues.append(Issue(Severity.TODO, "TABLE-A11Y", msg))

    def repl(m: re.Match) -> str:
        whole = m.group(0)
        if re.search(r"\\multicolumn|\\multirow", whole) or "\\begin{tabular}" in m.group("body"):
            _todo("A data table uses \\multicolumn/\\multirow or is nested, so it was left as a "
                  "plain tabular -- its header cells won't be marked <th> for screen readers. "
                  "Simplify it, or mark the table up by hand for accessibility.")
            return whole
        rows = _parse_rows(m.group("body"))
        if len(rows) < 2:
            return whole                                     # header-only / empty: leave
        header_cells, _ = rows[0]
        if not header_cells or not all(_BOLD_RE.search(c) for c in header_cells):
            return whole                                     # no bold header row: leave (renders natively)
        data_rows = rows[1:]
        ncol = len(header_cells)
        if any(len(cells) != ncol for cells, _ in data_rows):
            _todo("A data table has rows with differing cell counts, so it was left as a plain "
                  "tabular (not converted to an accessible HTML table) -- check the table's "
                  "structure and header markup by hand.")
            return whole
        html = _build_html(_alignments(m.group("spec")), header_cells, data_rows)
        # Never emit a backslash or math shift into the HTML block: they crash Chirun's HTML
        # parse. If a cell held maths/text we couldn't render as plain text, leave it native.
        if html is None or "\\" in html or "$" in html:
            _todo("A data table has cell maths that couldn't be rendered safely as plain text "
                  "(an unrecognised command), so it was left as a plain tabular -- its header "
                  "cells won't be marked <th> for screen readers. Simplify the cell maths, or "
                  "mark the table up by hand for accessibility.")
            return whole
        return _dual_mode(html, whole)

    return _TABULAR_RE.sub(repl, body), issues
